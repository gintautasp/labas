
	Kursim naujienų sąrašą iš respublika.lt
	
	
	<?php //= $html_webe ?>
	
	<?php
	
		print_r ( $rez );
	?>
	
	<div id="statistika" style="width: 100%; background-color: yellow">
		<?= count ( $rez ) ?>
	</div>